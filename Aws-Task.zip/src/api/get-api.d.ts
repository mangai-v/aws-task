import { APIGatewayProxyEvent, Context } from 'aws-lambda';
export declare const handler: (event: APIGatewayProxyEvent, context: Context) => Promise<{
    statusCode: number;
    body: string;
}>;
