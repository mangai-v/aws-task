import { Construct } from 'constructs';
import { Stack } from 'aws-cdk-lib';
import { LambdaIntegration } from 'aws-cdk-lib/aws-apigateway';
import { ApiStackProps } from '../src/infra/common/interface';
export declare class AwsTaskStack extends Stack {
    readonly getFunctionLambdaIntegration: LambdaIntegration;
    readonly postFunctionLambdaIntegration: LambdaIntegration;
    constructor(scope: Construct, id: string, props?: ApiStackProps);
}
